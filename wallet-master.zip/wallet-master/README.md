# e-Wallet app

A new Flutter application.

## Getting Started

Tutorial url : https://youtu.be/NZti_NZLXis

image credits : https://www.uplabs.com/posts/ewalle-portable-wallet

## Author
If you like my work, please consider supporting me with your kind contribution. Thank you!!!
<div><a href=https://paypal.me/kaushikchandru?locale.x=en_GB>paypal </a></div>
<div><a href=https://www.patreon.com/kaushikchandru>patreon</a></div>
