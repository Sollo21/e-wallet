package com.example.wallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
